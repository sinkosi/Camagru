
<!DOCTYPE html>
<html lang="en">
<head>
     <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="header.css">
</head>
<body>

    <div class = "nev"> 
    <div class='nevlink'>
    <div><h2 class='nev_h'>Email Verification</h2></div>
    </div>
    </div>
</body>
</html>
<?php
    echo "<br>";
    echo "<center style='zoom:1; color:green;'>AN EMAIL VERIFICATON LINK HAS BEEN SENT TO YOUR EMALI ADDRESS</center>";
    echo "<br>";
    echo "<center style='zoom:1'><a href=http://localhost:8080/GURUREPO/login.php>log in page</a></center>";
    include('./footer/footer.php');
?>
