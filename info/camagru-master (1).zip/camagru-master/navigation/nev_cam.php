<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="main.css">
</head>
<body>

    <div class = "nev"> 
    <div class='nevlink'>
    <div><h2 class='nev_h'>Camera</h2></div>
    <a href="gallery.php" class = "nev_a">Profile</a> 
    <a href="contents.php" class= "nev_a">upload</a>
    <a href="modify.php" class= "nev_a">edituser</a>
    <a href="index.php" class= "nev_a">public</a>
    <a href="logout.php" class= "nev_a">logout</a>
    </div>
    </div>
</body>
</html>