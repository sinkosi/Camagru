<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="main.css">
</head>
<body>

    <div class = "nev"> 
    <div class='nevlink'>
    <div><h2 class='nev_h'>Reset Your Password</h2></div>
    </div>
    </div>
</body>
</html>