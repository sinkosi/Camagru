<?php
require_once('./includes/views/layout/header.php');
?>
    <div class="content" id="404">
    <p>YOU HAVE DONE THE BAD!</p>
    <p>NAUGHTY!</p>
    <p>404</p>
    </div>
<?php
require_once('./includes/views/layout/footer.php');
?>